todoapp.controller('todocontroller', function($scope, $compile) {
    // Application Variables
    $scope.toDoTasks = [];

    // Application Callback Methods
    $scope.showToDoTask = function() {
        var taskItem = $scope.todotask;
        alert('TASK: ' + taskItem);
    };
    
    // Method to add new to do task
    $scope.addToDoTask = function() {
        var toDoItem = $scope.todotask;
        var taskCount = $scope.toDoTasks.length;
        if (toDoItem != '' && toDoItem != undefined) {
            $scope.toDoTasks.push(toDoItem);
            //var divId = "divTask" + (taskCount + 1);
            var divId = (taskCount + 1);
            var checkboxId = "checkbox" + (taskCount+1);
            
            var header = '<div id="' + divId + '" class="task-item-card" ng-mouseover="highlightItemCard(\''+ divId +'\')" ng-mouseleave="deHighlightItemCard(\'' + divId + '\')">'; 
            var basicCard = '<input type="checkbox" id="' + checkboxId + '" value="' + toDoItem + '" data-ng-click="showTaskCard(\'' + checkboxId + '\')" /><span style="width:200px;" id="lbl_' + checkboxId + '" class="normal wrap-text">' + toDoItem + '</span>';
            var mailGlyph = '<span style="display:none" class="glyphicon glyphicon-envelope float-right glyph-position"></span>';
            var trashGlyph = '<span style="display:none;" class="glyphicon glyphicon-trash float-right glyph-position" data-ng-click="deleteItemCard($event)"></span>';
            var reminderGlyph = '<span style="display:none;" class="glyphicon glyphicon-time float-right glyph-position" data-ng-click="setItemCardReminder()"></span>';
            var ender = '</div>';
            
            var itemCard = header + basicCard + mailGlyph + trashGlyph + reminderGlyph + ender;
            var tempItemCard = $compile(itemCard)($scope);
            $("#todo-container").append(tempItemCard);
            $scope.todotask = '';
            $('#txtToDoItem').focus();
        }
    }
    
    /* Method to show test message for clicking task card */
    $scope.showTaskCard = function(elementId) {
        console.log('Element Id: ' + elementId);
        var checkLabelId = 'lbl_' + elementId;
        if ($('#' + elementId).is(":checked") == true){
            $('#' + checkLabelId).removeClass('normal').addClass('strike-through');
        }
        else {
            $('#' + checkLabelId).removeClass('strike-through').addClass('normal');
        }        
    }
    
    /* Method to delete an item card */
    $scope.deleteItemCard = function($event) {
        //alert('This is to delete an item card');
        if ($event != 'undefined') {
            var currentItem = $event.target;
            var parentItem = $(currentItem).parent();
            var parentItemIndex = parentItem.attr('id') - 1;
            $(currentItem).parent().remove();   // Find the parent div element and remove it from the stack
            $scope.toDoTasks.splice(parentItemIndex, 1);
        }
    }
    
    /* Method to set a reminder for an item card */
    $scope.setItemCardReminder = function(objItem) {
        alert('This is to set a reminder for an item card');
    }
    
    /* Method to highlight an to do item card on mouse over */
    $scope.highlightItemCard = function(objItem) {
        $('#'+objItem).addClass('highlighter');
        $('#'+objItem).find("span.glyphicon-time").css("display","block");
        $('#'+objItem).find("span.glyphicon-trash").css("display","block");
        $('#'+objItem).find("span.glyphicon-envelope").css("display","block");
        //$("div.task-item-card").toggleClass("highlighter");
    }
    $scope.deHighlightItemCard = function(objItem) {
        $('#'+objItem).removeClass('highlighter');
        $('#'+objItem).find("span.glyphicon-time").css("display","none");
        $('#'+objItem).find("span.glyphicon-trash").css("display","none");
        $('#'+objItem).find("span.glyphicon-envelope").css("display","none");
        //$("div.task-item-card").toggleClass("highlighter");
    }
});